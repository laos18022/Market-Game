# Urile Biikuse — Website akun game + pesanan + feedback terverifikasi

## PENTING: deploy dengan cara yang mendukung backend
Fitur pesanan, panel admin pesanan, AI, dan feedback memakai Netlify Functions serta Netlify Blobs. **Jangan mengandalkan Netlify Drop untuk deployment statis**: bila fungsi tidak ikut dibangun atau tidak tersedia, data tidak dapat disimpan ke server.

### Cara deploy yang disarankan dari HP
1. Ekstrak ZIP ini.
2. Upload seluruh isi folder ke repository GitHub (file `index.html` harus ada di root repository, bukan di dalam folder tambahan).
3. Di Netlify, pilih **Add new site → Import an existing project** lalu hubungkan repository tersebut.
4. Pada Site configuration → Environment variables, tambahkan `ADMIN_PIN` (PIN rahasia admin) dan `ANTHROPIC_API_KEY` untuk fitur AI (opsional, API Anthropic dapat berbayar).
5. Jalankan deploy. Setelah selesai, buka `https://DOMAIN-KAMU/.netlify/functions/feedback?health=1`. Jika siap, responsnya `{"ok":true,"storage":"ready"}`.
6. Kalau endpoint health gagal, buka Netlify → Functions → `feedback` → Logs. Fungsi sekarang mencatat error server untuk membantu diagnosis.

> Jika situs sebelumnya sudah diunggah melalui Netlify Drop, hubungkan repo GitHub ke situs Netlify yang sama atau buat situs baru melalui Import an existing project. Jangan mengira folder `netlify/functions` otomatis aktif hanya karena file tersebut ada di ZIP.

## Fitur
- Panel admin: `/#admin`, tambah/edit/hapus listing, unggah foto, ekspor ZIP dan `stok.json`.
- AI bisa membuat DRAF judul/deskripsi dari foto jika `ANTHROPIC_API_KEY` tersedia. Verifikasi semua detail sendiri; AI tidak bisa memastikan detail akun yang tak terlihat.
- Pemesanan tercatat di server. Admin tetap mengonfirmasi stok/pembayaran dan serah-terima secara manual melalui WhatsApp.
- Feedback hanya diterima dengan kode pesanan valid yang sudah ditandai `completed`; satu feedback per kode.
- Feedback yang tersimpan ditampilkan ke publik; pesan error sekarang lebih jelas dan fungsi mencatat penyebab teknis di Logs.

## Konfigurasi & keamanan
- `ADMIN_PIN` harus sama dengan PIN yang digunakan ketika login ke panel admin.
- Jangan taruh API key di HTML/JavaScript dan jangan bagikan PIN admin.
- Jangan pernah memasukkan kata sandi, email login, atau kode pemulihan akun game ke kolom feedback atau AI.
- Data pesanan dan feedback disimpan menggunakan Netlify Blobs; ini bukan pemroses pembayaran otomatis.
