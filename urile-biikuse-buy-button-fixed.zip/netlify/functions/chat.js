// Asisten AI Urile Biikuse. Butuh env var ANTHROPIC_API_KEY di Netlify.
// Tanpa fungsi ini pun, chat di website tetap menjawab otomatis lewat asisten bawaan di index.html.
const INFO = 'Kamu asisten toko Urile Biikuse, jual beli akun game. Admin manusia online 08.00-18.00 WIB; di luar jam itu kamu yang menjawab. Cara beli: pilih akun di katalog, tekan Beli, lanjut ke WhatsApp admin. Cara jual: isi form Jual akun, admin menilai dan menawar. Pembayaran dan serah terima akun hanya dikonfirmasi admin manusia. Bantu pembeli memilih akun dari katalog sesuai game dan budget. Jangan mengarang akun, harga, atau stok di luar katalog. Jawab singkat (maksimal 3 kalimat) dalam Bahasa Indonesia yang ramah.';
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: '' };
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return { statusCode: 503, body: JSON.stringify({ error: 'ANTHROPIC_API_KEY belum diisi' }) };
  let b;
  try { b = JSON.parse(event.body || '{}'); } catch { return { statusCode: 400, body: '' }; }
  const msgs = [];
  for (const raw of (Array.isArray(b.history) ? b.history : []).slice(-8)) {
    const s = String(raw).slice(0, 500);
    const role = s.startsWith('Asisten:') ? 'assistant' : 'user';
    const text = s.replace(/^(Pembeli|Asisten):\s*/, '').trim();
    if (!text) continue;
    if (msgs.length && msgs[msgs.length - 1].role === role) msgs[msgs.length - 1].content += '\n' + text;
    else msgs.push({ role, content: text });
  }
  while (msgs.length && msgs[0].role !== 'user') msgs.shift();
  if (!msgs.length || msgs[msgs.length - 1].role !== 'user') return { statusCode: 400, body: '' };
  const h = (new Date().getUTCHours() + 7) % 24;
  const status = h >= 8 && h < 18 ? 'Sekarang admin online.' : 'Sekarang admin istirahat, kembali 08.00 WIB.';
  const catalog = String(b.catalog || '').slice(0, 3000);
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-haiku-5-5',
        max_tokens: 300,
        system: INFO + ' ' + status + ' Katalog: ' + catalog,
        messages: msgs
      })
    });
    if (!r.ok) return { statusCode: 502, body: JSON.stringify({ error: 'upstream' }) };
    const d = await r.json();
    const reply = (d.content || []).filter(c => c.type === 'text').map(c => c.text).join('');
    return { statusCode: 200, headers: { 'content-type': 'application/json' }, body: JSON.stringify({ reply }) };
  } catch { return { statusCode: 502, body: JSON.stringify({ error: 'network' }) }; }
};
