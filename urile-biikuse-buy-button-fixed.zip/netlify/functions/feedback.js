const { getStore } = require('@netlify/blobs');

const ordersStore = () => getStore('ub-orders');
const feedbackStore = () => getStore('ub-feedback');
const json = (statusCode, body) => ({
  statusCode,
  headers: {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store, max-age=0',
    'x-content-type-options': 'nosniff'
  },
  body: JSON.stringify(body)
});

function publicError(err) {
  // The real error is kept in Netlify function logs, not exposed to visitors.
  console.error('[feedback] storage/request failure:', err && (err.stack || err.message || err));
  return json(503, {
    error: 'FEEDBACK_STORAGE_UNAVAILABLE',
    message: 'Penyimpanan feedback belum terhubung. Admin perlu memeriksa deploy Netlify dan Netlify Blobs.'
  });
}

exports.handler = async (event) => {
  try {
    const method = event.httpMethod;
    const orders = ordersStore();
    const feedback = feedbackStore();

    // Private-detail-free diagnostic endpoint for deployment checks.
    if (method === 'GET' && event.queryStringParameters?.health === '1') {
      await Promise.all([orders.list({ limit: 1 }), feedback.list({ limit: 1 })]);
      return json(200, { ok: true, storage: 'ready' });
    }

    if (method === 'GET') {
      const result = await feedback.list();
      const entries = await Promise.all((result.blobs || []).map(async (blob) => {
        try { return await feedback.get(blob.key, { type: 'json' }); }
        catch (err) { console.error('[feedback] could not read item:', blob.key, err); return null; }
      }));
      const visible = entries
        .filter((item) => item && item.status === 'approved')
        .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')))
        .slice(0, 100);
      return json(200, { feedback: visible });
    }

    if (method !== 'POST') {
      return json(405, { error: 'METHOD_NOT_ALLOWED' });
    }

    let body;
    try { body = JSON.parse(event.body || '{}'); }
    catch { return json(400, { error: 'INVALID_JSON', message: 'Data feedback tidak valid.' }); }

    const code = String(body.code || '').trim().toUpperCase();
    const rating = Number(body.rating);
    const message = String(body.message || '').trim();
    if (!/^UB-[A-Z0-9]{4,12}$/.test(code) || !Number.isInteger(rating) || rating < 1 || rating > 5 || message.length < 3 || message.length > 600) {
      return json(400, { error: 'INVALID_FEEDBACK', message: 'Isi kode pesanan, rating 1–5, dan feedback 3–600 karakter.' });
    }

    const order = await orders.get(code, { type: 'json' });
    if (!order) return json(404, { error: 'ORDER_NOT_FOUND', message: 'Kode pesanan tidak ditemukan. Periksa kembali kode pesanan.' });
    if (order.status !== 'completed') {
      return json(403, { error: 'ORDER_NOT_COMPLETED', message: 'Pesanan belum ditandai selesai oleh admin.' });
    }

    const existing = await feedback.get(code, { type: 'json' });
    if (existing) return json(409, { error: 'FEEDBACK_ALREADY_EXISTS', message: 'Feedback untuk pesanan ini sudah pernah dikirim.' });

    const item = {
      code,
      rating,
      message,
      name: 'Pelanggan terverifikasi',
      date: new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta' }),
      createdAt: new Date().toISOString(),
      status: 'approved'
    };
    await feedback.setJSON(code, item);
    return json(201, { ok: true, message: 'Feedback berhasil dikirim. Terima kasih!' });
  } catch (err) {
    return publicError(err);
  }
};
